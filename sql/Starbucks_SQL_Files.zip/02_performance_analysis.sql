-- Starbucks Business Turnaround
-- 02_performance_analysis.sql
-- PostgreSQL

-- 1. Year-over-year revenue growth
SELECT
    fiscal_year,
    revenue_m,
    ROUND(
        (((revenue_m / NULLIF(LAG(revenue_m) OVER (ORDER BY fiscal_year),0)) - 1) * 100)::numeric,
        2
    ) AS calculated_revenue_growth_pct
FROM starbucks_turnaround
ORDER BY fiscal_year;

-- 2. Year-over-year operating income growth
SELECT
    fiscal_year,
    operating_income_m,
    ROUND(
        (((operating_income_m / NULLIF(LAG(operating_income_m) OVER (ORDER BY fiscal_year),0)) - 1) * 100)::numeric,
        2
    ) AS calculated_operating_income_growth_pct
FROM starbucks_turnaround
ORDER BY fiscal_year;

-- 3. Revenue and operating income change from FY2021
SELECT
    fiscal_year,
    revenue_m,
    operating_income_m,
    ROUND(
        (((revenue_m / FIRST_VALUE(revenue_m) OVER (ORDER BY fiscal_year)) - 1) * 100)::numeric,
        2
    ) AS revenue_change_from_fy2021_pct,
    ROUND(
        (((operating_income_m / FIRST_VALUE(operating_income_m) OVER (ORDER BY fiscal_year)) - 1) * 100)::numeric,
        2
    ) AS operating_income_change_from_fy2021_pct
FROM starbucks_turnaround
ORDER BY fiscal_year;

-- 4. Operating margin trend
SELECT
    fiscal_year,
    ROUND(((operating_income_m / NULLIF(revenue_m,0)) * 100)::numeric, 2)
        AS calculated_operating_margin_pct,
    operating_margin_pct AS source_operating_margin_pct
FROM starbucks_turnaround
ORDER BY fiscal_year;

-- 5. Store growth and revenue per store
SELECT
    fiscal_year,
    stores,
    ROUND(
        (((stores::numeric / NULLIF(LAG(stores) OVER (ORDER BY fiscal_year),0)) - 1) * 100)::numeric,
        2
    ) AS calculated_store_growth_pct,
    ROUND((revenue_m * 1000000.0 / NULLIF(stores,0))::numeric, 0)
        AS revenue_per_store_dollars
FROM starbucks_turnaround
ORDER BY fiscal_year;

-- 6. Largest annual operating-income decline
WITH annual_change AS (
    SELECT
        fiscal_year,
        operating_income_m,
        operating_income_m - LAG(operating_income_m)
            OVER (ORDER BY fiscal_year) AS change_m
    FROM starbucks_turnaround
)
SELECT
    fiscal_year,
    operating_income_m,
    ROUND(change_m::numeric, 1) AS operating_income_change_m
FROM annual_change
WHERE change_m IS NOT NULL
ORDER BY change_m
LIMIT 1;

-- 7. Global comparable-store sales components
SELECT
    fiscal_year,
    global_comp_pct,
    global_transactions_pct,
    global_ticket_pct
FROM starbucks_turnaround
WHERE global_comp_pct IS NOT NULL
ORDER BY fiscal_year;

-- 8. North America vs China transaction trends
SELECT
    fiscal_year,
    na_transactions_pct,
    china_transactions_pct
FROM starbucks_turnaround
WHERE na_transactions_pct IS NOT NULL
   OR china_transactions_pct IS NOT NULL
ORDER BY fiscal_year;

-- 9. FY2025 profitability snapshot
SELECT
    fiscal_year,
    revenue_m,
    operating_income_m,
    net_earnings_m,
    stores,
    operating_margin_pct,
    restructuring_impairment_m
FROM starbucks_turnaround
WHERE fiscal_year = 2025;
