-- Starbucks Business Turnaround
-- 03_turnaround_analysis.sql
-- PostgreSQL

-- 1. Management diagnostic view
WITH diagnostic AS (
    SELECT
        fiscal_year,
        revenue_m,
        operating_income_m,
        stores,
        operating_margin_pct,
        global_comp_pct,
        global_transactions_pct,
        global_ticket_pct,
        na_transactions_pct,
        china_transactions_pct,
        restructuring_impairment_m,
        revenue_m * 1000000.0 / NULLIF(stores,0) AS revenue_per_store_dollars
    FROM starbucks_turnaround
)
SELECT *
FROM diagnostic
ORDER BY fiscal_year;

-- 2. Years where revenue grew but operating income fell
SELECT
    fiscal_year,
    revenue_growth_pct,
    operating_income_growth_pct,
    revenue_m,
    operating_income_m
FROM starbucks_turnaround
WHERE revenue_growth_pct > 0
  AND operating_income_growth_pct < 0
ORDER BY fiscal_year;

-- 3. Years with negative global comparable-store performance
SELECT
    fiscal_year,
    global_comp_pct,
    global_transactions_pct,
    global_ticket_pct
FROM starbucks_turnaround
WHERE global_comp_pct < 0
ORDER BY fiscal_year;

-- 4. Identify the primary demand pressure
SELECT
    fiscal_year,
    global_transactions_pct,
    global_ticket_pct,
    CASE
        WHEN global_transactions_pct IS NULL THEN 'No transaction data'
        WHEN ABS(global_transactions_pct) > ABS(global_ticket_pct)
            THEN 'Transactions had larger movement'
        WHEN ABS(global_transactions_pct) < ABS(global_ticket_pct)
            THEN 'Ticket had larger movement'
        ELSE 'Equal movement'
    END AS primary_demand_driver
FROM starbucks_turnaround
WHERE global_transactions_pct IS NOT NULL
ORDER BY fiscal_year;

-- 5. FY2024 to FY2025 operating-income bridge
WITH p AS (
    SELECT
        MAX(CASE WHEN fiscal_year = 2024 THEN operating_income_m END) AS op_2024,
        MAX(CASE WHEN fiscal_year = 2025 THEN operating_income_m END) AS op_2025,
        MAX(CASE WHEN fiscal_year = 2024 THEN revenue_m END) AS rev_2024,
        MAX(CASE WHEN fiscal_year = 2025 THEN revenue_m END) AS rev_2025
    FROM starbucks_turnaround
)
SELECT
    ROUND(op_2024::numeric, 1) AS fy2024_operating_income_m,
    ROUND(op_2025::numeric, 1) AS fy2025_operating_income_m,
    ROUND((op_2025 - op_2024)::numeric, 1) AS operating_income_change_m,
    ROUND((((op_2025 / NULLIF(op_2024,0)) - 1) * 100)::numeric, 2)
        AS operating_income_change_pct,
    ROUND((rev_2025 - rev_2024)::numeric, 1) AS revenue_change_m
FROM p;

-- 6. Store productivity trend
WITH productivity AS (
    SELECT
        fiscal_year,
        revenue_m * 1000000.0 / NULLIF(stores,0) AS revenue_per_store
    FROM starbucks_turnaround
)
SELECT
    fiscal_year,
    ROUND(revenue_per_store::numeric, 0) AS revenue_per_store_dollars,
    ROUND(
        (((revenue_per_store / NULLIF(LAG(revenue_per_store)
            OVER (ORDER BY fiscal_year),0)) - 1) * 100)::numeric,
        2
    ) AS revenue_per_store_growth_pct
FROM productivity
ORDER BY fiscal_year;

-- 7. Restructuring / impairment impact
SELECT
    fiscal_year,
    restructuring_impairment_m,
    CASE
        WHEN restructuring_impairment_m IS NULL THEN 'No reported value'
        WHEN restructuring_impairment_m > 0 THEN 'Reported restructuring/impairment'
        ELSE 'None'
    END AS restructuring_flag
FROM starbucks_turnaround
ORDER BY fiscal_year;

-- 8. Simple turnaround priority score
-- This is an analytical project metric, not a Starbucks-published metric.
WITH latest AS (
    SELECT *
    FROM starbucks_turnaround
    WHERE fiscal_year = (SELECT MAX(fiscal_year) FROM starbucks_turnaround)
),
scores AS (
    SELECT
        fiscal_year,
        CASE WHEN global_transactions_pct < 0 THEN 2
             WHEN global_transactions_pct = 0 THEN 1 ELSE 0 END AS traffic_pressure,
        CASE WHEN operating_margin_pct < 10 THEN 2
             WHEN operating_margin_pct < 15 THEN 1 ELSE 0 END AS margin_pressure,
        CASE WHEN revenue_per_store_m < (
                SELECT AVG(revenue_per_store_m)
                FROM starbucks_turnaround
             ) THEN 2 ELSE 0 END AS productivity_pressure
    FROM latest
)
SELECT
    fiscal_year,
    traffic_pressure,
    margin_pressure,
    productivity_pressure,
    traffic_pressure + margin_pressure + productivity_pressure
        AS turnaround_priority_score
FROM scores;

-- 9. FY2025 executive diagnosis
SELECT 'Revenue' AS metric, ROUND(revenue_m::numeric,1) AS value
FROM starbucks_turnaround WHERE fiscal_year=2025
UNION ALL
SELECT 'Operating Income', ROUND(operating_income_m::numeric,1)
FROM starbucks_turnaround WHERE fiscal_year=2025
UNION ALL
SELECT 'Operating Margin %', ROUND(operating_margin_pct::numeric,1)
FROM starbucks_turnaround WHERE fiscal_year=2025
UNION ALL
SELECT 'Stores', stores::numeric
FROM starbucks_turnaround WHERE fiscal_year=2025
UNION ALL
SELECT 'Restructuring / Impairment', ROUND(restructuring_impairment_m::numeric,1)
FROM starbucks_turnaround WHERE fiscal_year=2025;
