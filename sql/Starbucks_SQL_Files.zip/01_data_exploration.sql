-- Starbucks Business Turnaround
-- 01_data_exploration.sql
-- PostgreSQL
-- Assumption: CSV has already been imported into table: starbucks_turnaround

-- 1. Inspect the dataset
SELECT * FROM starbucks_turnaround ORDER BY fiscal_year;

-- 2. Row count
SELECT COUNT(*) AS row_count FROM starbucks_turnaround;

-- 3. Available years
SELECT DISTINCT fiscal_year
FROM starbucks_turnaround
ORDER BY fiscal_year;

-- 4. Core financial metrics
SELECT fiscal_year, revenue_m, operating_income_m, stores, operating_margin_pct
FROM starbucks_turnaround
ORDER BY fiscal_year;

-- 5. Missing values in key fields
SELECT
    COUNT(*) FILTER (WHERE revenue_m IS NULL) AS missing_revenue,
    COUNT(*) FILTER (WHERE operating_income_m IS NULL) AS missing_operating_income,
    COUNT(*) FILTER (WHERE stores IS NULL) AS missing_stores,
    COUNT(*) FILTER (WHERE global_comp_pct IS NULL) AS missing_global_comp,
    COUNT(*) FILTER (WHERE global_transactions_pct IS NULL) AS missing_global_transactions,
    COUNT(*) FILTER (WHERE global_ticket_pct IS NULL) AS missing_global_ticket
FROM starbucks_turnaround;

-- 6. Basic statistics
SELECT
    MIN(revenue_m) AS min_revenue_m,
    MAX(revenue_m) AS max_revenue_m,
    AVG(revenue_m) AS avg_revenue_m,
    MIN(operating_income_m) AS min_operating_income_m,
    MAX(operating_income_m) AS max_operating_income_m,
    AVG(operating_income_m) AS avg_operating_income_m
FROM starbucks_turnaround;

-- 7. Independently calculate revenue per store
SELECT
    fiscal_year,
    revenue_m,
    stores,
    ROUND((revenue_m * 1000000.0 / NULLIF(stores,0))::numeric, 0)
        AS revenue_per_store_dollars
FROM starbucks_turnaround
ORDER BY fiscal_year;
